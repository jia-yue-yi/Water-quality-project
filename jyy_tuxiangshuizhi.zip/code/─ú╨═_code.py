#!/usr/bin/env python
# coding: utf-8

# In[40]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import model_selection
import numpy as np
#导入颜色矩数据
f = open('D://Desktop//be used//实习//泰迪图像水质//tdata.csv')
data = pd.read_csv(f)


# In[41]:


data = data.as_matrix()
#划分测试集和训练集
from sklearn.cross_validation import train_test_split
x_train,x_test,y_train,y_test = train_test_split(data[:,2:]*30,data[:,0],test_size=0.2, random_state=42)


# In[33]:


#建立训练模型
from sklearn.svm import SVC
model=SVC().fit(x_train,y_train)


# In[35]:


#混淆矩阵
#导入输出相关的库，生成混淆矩阵
from sklearn import metrics

cm_train = metrics.confusion_matrix(y_train, model.predict(x_train))
cm_test = metrics.confusion_matrix(y_test, model.predict(x_test))
pd.DataFrame(cm_train, index=range(1,6),columns=range(1,6)).to_excel('cm_train.xls')#模型混淆矩阵
pd.DataFrame(cm_test, index=range(1,6),columns=range(1,6)).to_excel('metrics_test.xls')#水质检测混淆矩阵
print (cm_train)
print (cm_test)


# In[38]:


#报告
print (metrics.classification_report(y_train, model.predict(x_train)))
print (metrics.classification_report(y_test, model.predict(x_test)))


# In[39]:


#准确率
from sklearn.metrics import accuracy_score
print (accuracy_score(y_train, model.predict(x_train)))
print (accuracy_score(y_test, model.predict(x_test)))


# In[ ]:




